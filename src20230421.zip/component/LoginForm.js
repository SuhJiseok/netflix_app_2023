import React, { useState } from 'react'
import "styles/LoginForm.css"
function LoginForm() {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Implement your login logic here
    
  };
  const [newAccount, setNewAccount] = useState(true);
  const toggleAccount = () => setNewAccount(prev => !prev);
  return (
    <div className='login-wrapper'>
      <div className="login-form">
        <form onSubmit={handleSubmit}>
          <h2>Sign in</h2>
          <div className='inputbox'>
          <input type="email" id="email" name="email" required="required" />
          <span>Username</span>
          <i></i>
          </div>
          <div className='inputbox'>
          <input type="password" id="password" name="password" required="required" />
          <span>Password</span>
          <i></i>
          </div>
          <div class="links">
            <a href='#'>Forgot Password</a>
            <a href='#' onClick={toggleAccount}>{newAccount ? "Sign In" : "Create Account"}</a>
          </div>         
          <input type='submit' value="Login"></input>
        </form>
      </div>
    </div>
  );
}
export default LoginForm